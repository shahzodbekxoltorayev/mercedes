import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-catalog',
  templateUrl: './all-catalog.component.html',
  styleUrls: ['./all-catalog.component.css']
})
export class AllCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
