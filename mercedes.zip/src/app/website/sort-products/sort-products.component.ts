import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sort-products',
  templateUrl: './sort-products.component.html',
  styleUrls: ['./sort-products.component.css']
})
export class SortProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
