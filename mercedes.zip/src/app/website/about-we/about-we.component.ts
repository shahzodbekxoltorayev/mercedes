import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-we',
  templateUrl: './about-we.component.html',
  styleUrls: ['./about-we.component.css']
})
export class AboutWeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
